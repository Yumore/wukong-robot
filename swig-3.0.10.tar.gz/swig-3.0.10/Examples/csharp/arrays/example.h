
void myArrayCopy( int *sourceArray, int* targetArray, int nitems );
void myArraySwap( int* array1, int* array2, int nitems );

